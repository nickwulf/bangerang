#include ".\post.h"
#include ".\wall.h"
#include ".\car.h"
#include ".\ground.h"
#using <mscorlib.dll>

#include <stdlib.h>
#include "glm.h"
#include "glut.h"
#include <stdarg.h>
#include <iostream>
#include <memory.h>
#include <time.h>
#include <fstream>
#include <sstream>
#include <cmath>
using namespace std;

// Definitions
#define DEG_TO_RAD 0.0174532925
#define RAD_TO_DEG 57.29577951
#define DETECT_HEIGHT 1.15

Post::Post(void) {
}

float Post::testNear(float point[], float tall, float postPoint[]) {
	float distance = 1000;
	if (on) {
		if ((point[1]<=height+posY+DETECT_HEIGHT) && (point[1]+tall>=posY))
			distance = sqrt(pow(point[0]-posX,2) + pow(point[2]-posZ,2));
		postPoint[0] = posX;
		postPoint[1] = point[1];
		postPoint[2] = posZ;
	}
	return distance;
}

void Post::setPosition(float p[]) {
	for (int i=0; i<3; i++) {
		posX = p[0];
		posY = p[1];
		posZ = p[2];
	}
}

void Post::setHeight(float h) {
	height = h;
}

void Post::setOn(bool value) {
	on = value;
}

void Post::getPosition(float p[]) {
	for (int i=0; i<3; i++) {
		p[0] = posX;
		p[1] = posY;
		p[2] = posZ;
	}
}

float Post::getHeight() {
	return height;
}

bool Post::getOn() {
	return on;
}

Post::~Post(void) {
}
