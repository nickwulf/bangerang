#pragma once

class Car
{
public:
	Car(void);
	void draw();
	void update(int keyDown[]);
	void setPosition(float pos[]);
	void setVelocity(float vel[]);
	void setAngle(float ang);
	void setOmega(float omg);
	void setRadius(float rad);
	void setElevation(float elev);
	void setNormal(float n[]);
	void getPosition(float pos[]);
	void getVelocity(float vel[]);
	float getAngle();
	float getOmega();
	float getRadius();
	float getElevation();
	void getNormal(float n[]);
	virtual ~Car(void);
public:
	float posX;
	float posY;
	float posZ;
	float velX;
	float velY;
	float velZ;
	float angle;
	float omega;
	float radius;
	float elevation; // how high the ground is below the car
	float norm[3]; // normal to the plane of the car (normalized)
};
