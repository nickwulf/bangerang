#include <stdlib.h>
#include "glm.h"
#include "glut.h"
#include <stdarg.h>
#include <iostream>
#include <memory.h>
#include <time.h>
#include <fstream>
#include <sstream>
#include <cmath>
using namespace std;

#include ".\car.h"
#include ".\ground.h"
#include ".\wall.h"
#include ".\post.h"

// Definitions
#define DEG_TO_RAD 0.0174532925
#define RAD_TO_DEG 57.29577951
#define DETECT_HEIGHT 1.15

// Default Image dimensions
int imageWidth=800;
int imageHeight=600;

// Mouse variables
bool mouseLeft=false, mouseRight=false;
int mousePosX, mousePosY, mouseVelX, mouseVelY;

// Screen positioning variables
float camThetaX=180, camThetaY=30, camOmegaX=0, camOmegaY=0, camDis=100, camVel=0;
float camPosX, camPosY, camPosZ, camDesX, camDesY, camDesZ;
bool camMove = false;

// Framerate variables
int clockThen=clock();  // used to determine how long a second is
int frameCount=0;  // used to determine how many frames have been in the last second
int frameRate=0;

// Car variables
Car car1;
float carPos[3];  // These 3 variables are used for
float carVel[3];  //   grabbing and storing temporary
float carNorm[3]; //   car variables

// Debugging variables
float minY=1000;
float floatValue=3;
float debug;
bool boolValue=false;
float test[3];

// Other object variables
Ground grounds[10];
Wall walls[10];
Post posts[10];

// Keyboard Array
int keyDown[256];

//OpenGL Calls
void setupGL();
void CheckGLError();

//Callbacks
void Display();
void Idle();
void Reshape(int w, int h);
void Keyboard (unsigned char key, int , int );
void KeyboardUp (unsigned char key, int , int );
void MouseButton(int button, int state, int x, int y);
void MouseMotion(int x, int y);
void MousePassiveMotion(int x, int y);

// Other Methods
void setupGame();
void testCarGround();
void testCarWall();
void doLighting();
void updateKeyInput();
void updateCamera();
void displayHUD();
void drawString(float x, float y, void *font, string s, float r, float g, float b);
string intToString(int i);
string floatToString(float f, int decPlace);

//font
GLvoid *font_style = GLUT_BITMAP_HELVETICA_12;

// a cleanup function
void quit(int i = 0);


void main(int argc, char **argv) {
	// INITIALIZE THE GLUT WINDOW
	memset(keyDown,0,sizeof(keyDown));
	glutInit(&argc, argv);  
	glutInitWindowSize(imageWidth, imageHeight);
	glutInitDisplayString("rgb double");
	glutInitWindowPosition(0, 0);
	glutCreateWindow("Project #1");

	//SETUP GLUT CALLBACKS
	cout << "Setting up callbacks... ";
	glutDisplayFunc(Display);
	glutKeyboardFunc(Keyboard);
	glutKeyboardUpFunc(KeyboardUp);
	glutMouseFunc(MouseButton);
	glutMotionFunc(MouseMotion);
	glutPassiveMotionFunc(MousePassiveMotion);
	glutReshapeFunc(Reshape);
	glutIdleFunc(Idle);
	cout << "[completed]\n";
	glEnable(GL_DEPTH_TEST);

	//SETUP MISC GL
	setupGL();
	CheckGLError();

	setupGame(); // setup game parameters

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_NORMALIZE);
	glMatrixMode(GL_MODELVIEW);
	glutMainLoop();
}

// This function checks the state of openGL and prints 
// an error if an error has occurred
void CheckGLError()
{
  	GLenum error;
  	error = glGetError();
  	if (error!=GL_NO_ERROR)
  	{
		cout << "OpenGL reports an error: "<< gluErrorString(error) << endl;
		quit(1);
  	}
}

// This function draws the scene
void Display() {
	// clear the screen
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	testCarGround();  // used for collision detection
	car1.updateMovement(keyDown); // read the key presses and move the car accordingly
	testCarWall();
	car1.updatePosition(); // read the key presses and move the car accordingly
	updateKeyInput(); // read other key presses
	updateCamera(); // move the camera to the correct position

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
		glLoadIdentity();
		car1.getPosition(carPos);
		gluLookAt(camPosX,camPosY,camPosZ,carPos[0],carPos[1]+13,carPos[2],0,1,0);
		doLighting();
		car1.draw();
		for (int i=0; i<10; i++) {
			grounds[i].draw();
			walls[i].draw();
		}
	glPopMatrix();

	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
		glLoadIdentity();
		gluOrtho2D(-400,400,-300,300);
		displayHUD();
	glPopMatrix();

	// swap the buffers
	glutSwapBuffers();
}

void testCarGround() {
	car1.getPosition(carPos);  // grabs the car position
	car1.getVelocity(carVel);  // grabs the car position
	float radius = car1.getRadius();
	float tall = car1.getTall();
	float height = -1000;  // The new heights are tested against this
	float norm[4];
	for (int i=0; i<10; i++) {
		if (grounds[i].testAbove(carPos, radius))	{  // if the car is above a floor block then
			float newHeight = grounds[i].getHeight(carPos);  // look at the height of the floor directly below the car
			if (newHeight > height && newHeight < carPos[1]-DETECT_HEIGHT-carVel[1]) {  // if this height is bigger than the old height and not too much above the car then
				height = newHeight;  // remember the new height
				if (carPos[1] < height+1.98) {  // if the car is close enough to the ground then
					grounds[i].getNormal(norm);  // find the normal to the ground plane
					car1.setNormal(norm);  // and tell the car what it is
					debug = -1.5-carVel[1];
				}
			}
		}
	}
	car1.setElevation(height);  // tell the car how high above the ground it is
}

void testCarWall() {
	car1.getPosition(carPos);  // grabs the car position
	float radius = car1.getRadius();
	float tall = car1.getTall();
	float wallPoint[3];
	for (int i=0; i<10; i++) {
		float wallDis = walls[i].testInFrontOf(carPos, tall, wallPoint);
		if (wallDis <= radius) {
			car1.updateWall(wallPoint, wallDis);
		}
	}
	float postPoint[3];
	for (int i=0; i<10; i++) {
		float postDis = posts[i].testNear(carPos, tall, postPoint);
		if (postDis <= radius) {
			car1.updateWall(postPoint, postDis);
		}
	}
}

void doLighting() {
	GLfloat ambient0[] = {.7, .7, .7, 1};
	GLfloat diffuse0[] = {.2, .2, .2, 1};
	GLfloat position0[] = {10, 20, 8, 0};
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse0);
	glLightfv(GL_LIGHT0, GL_AMBIENT, diffuse0);
	glLightfv(GL_LIGHT0, GL_POSITION, position0);
}

void updateKeyInput() {
	if (keyDown['c'] == 1) {
		keyDown['c'] = 2;
		camMove = !camMove;  // toggle free camera movement by pressing 'c'
	}
}

void updateCamera() {
	if (mouseLeft) {
		camOmegaX = (float)mouseVelX * (0.2);
		camOmegaY = (float)mouseVelY * (-0.2);
	}
	else if (mouseRight) {
		camVel = (float)mouseVelY * (0.5);
	}
	mouseVelX = 0;
	mouseVelY = 0;

	camThetaX += camOmegaX;  // omega is the change in theta over time
	camThetaY += camOmegaY;
	camDis += camVel;
	
	if (camThetaX > 360) camThetaX -= 360;
	else if (camThetaX < -360) camThetaX += 360;
	if (camThetaY >= 90) {
		camThetaY = 90;
		camOmegaY = 0;
	}
	else if (camThetaY <= -90) {
		camThetaY = -90;
		camOmegaY = 0;
	}
	if (camDis >= 2000) {
		camDis = 2000;
		camVel = 0;
	}
	else if (camDis <= 5) {
		camDis = 5;
		camVel = 0;
	}
	car1.getPosition(carPos);  // obtain the information about the car
	car1.getNormal(carNorm);
	if (camMove) {  // if the user is controlling the car then keep the camera upright and convert the polor coordinates into cartesian
		camDesX = carPos[0]+camDis*cos(camThetaY*DEG_TO_RAD)*cos((camThetaX+car1.getAngle())*DEG_TO_RAD);
		camDesZ = carPos[2]+camDis*cos(camThetaY*DEG_TO_RAD)*sin((camThetaX+car1.getAngle())*DEG_TO_RAD);
		camDesY = carPos[1]+camDis*sin(camThetaY*DEG_TO_RAD);
	}
	else {
		// A dot B = |A||B|cos(theta);  A = carNorm;  B = direction of cam in xz-plane
		float tempX = 40*cos(20*DEG_TO_RAD)*cos((180+car1.getAngle())*DEG_TO_RAD);  // Find where the camera should
		float tempZ = 40*cos(20*DEG_TO_RAD)*sin((180+car1.getAngle())*DEG_TO_RAD);  //   be on the xz-plane with respect to the car
		float magnitude = sqrt(pow(tempX,2)+pow(tempZ,2));  // find the magnitude of its distance to the car along this plane
		float bVector[3] = {tempX/magnitude, 0, tempZ/magnitude};  // create a normalized vector that lies in xz-plane and faces direction of car
		float pivotAngle = RAD_TO_DEG*acos(carNorm[0]*bVector[0] + carNorm[1]*bVector[1] + carNorm[2]*bVector[2]);  // use dot product to find the angle
		pivotAngle = pivotAngle-90;															// that the camera should pivot at to line up with ground
		camDesX = carPos[0]+40*cos((20+pivotAngle)*DEG_TO_RAD)*cos((180+car1.getAngle())*DEG_TO_RAD);  // convert from polar to cartesian
		camDesZ = carPos[2]+40*cos((20+pivotAngle)*DEG_TO_RAD)*sin((180+car1.getAngle())*DEG_TO_RAD);
		camDesY = carPos[1]+40*sin((20+pivotAngle)*DEG_TO_RAD);
	}
	camPosX += 0.15*(camDesX-camPosX);  // move to camera closer and closer to where it needs to be
	camPosY += 0.15*(camDesY-camPosY);  // causes a smoothing effect
	camPosZ += 0.15*(camDesZ-camPosZ);
}

void displayHUD() {  // helps to display debuging info
	string text;
	car1.getPosition(carPos);
	car1.getVelocity(carVel);

//	text = "Height: " + floatToString(height,-1);
//	drawString(-370, -180, GLUT_BITMAP_HELVETICA_12, text, 0, 0, 0);

	text = "CamThetaY: " + floatToString(camThetaY,-1);
	drawString(-370, -195, GLUT_BITMAP_HELVETICA_12, text, 0, 0, 0);

	text = "Wall Test: " + floatToString(debug,-1);
	drawString(-370, -210, GLUT_BITMAP_HELVETICA_12, text, 0, 0, 0);

	text = "Y: " + floatToString(carPos[1],-1);
	drawString(-370, -225, GLUT_BITMAP_HELVETICA_12, text, 0, 0, 0);

	text = "Vel Y: " + floatToString(carVel[1],-1);
	drawString(-370, -240, GLUT_BITMAP_HELVETICA_12, text, 0, 0, 0);

	car1.getVelocity(carVel);
	text = "Speed: " + floatToString(sqrt(pow(carVel[0],2)+pow(carVel[1],2)+pow(carVel[2],2)),-1);
	drawString(-370, -255, GLUT_BITMAP_HELVETICA_12, text, 0, 0, 0);

	// show framerate
	frameCount++;
	int clockNow = clock();
	int clockCount = clockNow - clockThen;
	if ((clockCount>=1000) || (clockCount<=-1)) {
		frameRate = (int)(1000*frameCount/clockCount);
		frameCount = 0;
		clockThen = clockNow;
	}
	text = "FPS: " + intToString(frameRate);
	drawString(-370, -270, GLUT_BITMAP_HELVETICA_12, text, 0, 0, 0);
}

void setupGame() {  // Initialize game
	// Create the ground segments; The first vertex needs to be the center; It's used for collision detection
	float groundVerts0[5][3] = {{0,0,0}, {-100,-40,-100}, {100,0,-100}, {100,0,100}, {-100,-40,100}};
	bool conCorner0[4] = {1,1,1,1}; // tells which corners are connected to other ground pieces
	bool conSide0[4] = {0,1,0,1}; // tells which sides are connected to other ground pieces
	float groundVerts1[5][3] = {{300,0,0}, {100,0,-100}, {500,0,-100}, {500,0,100}, {100,0,100}};
	bool conCorner1[4] = {1,0,0,1};
	bool conSide1[4] = {0,0,0,1};
	float groundVerts2[5][3] = {{-200,-40,0}, {-300,-40,-100}, {-100,-40,-100}, {-100,-40,100}, {-300,-40,100}};
	bool conCorner2[4] = {0,1,1,0};
	bool conSide2[4] = {0,1,0,0};
	float groundVerts3[5][3] = {{300,5,0}, {200,0,50}, {400,10,50}, {400,10,-50}, {200,0,-50}};
	bool conCorner3[4] = {0,0,0,0};
	bool conSide3[4] = {0,0,0,0};
	grounds[0].setVertices(groundVerts0);
	grounds[0].setConnectedCorners(conCorner0);
	grounds[0].setConnectedSides(conSide0);
	grounds[0].setOn(true);
	grounds[1].setVertices(groundVerts1);
	grounds[1].setConnectedCorners(conCorner1);
	grounds[1].setConnectedSides(conSide1);
	grounds[1].setOn(true);
	grounds[2].setVertices(groundVerts2);
	grounds[2].setConnectedCorners(conCorner2);
	grounds[2].setConnectedSides(conSide2);
	grounds[2].setOn(true);
	grounds[3].setVertices(groundVerts3);
	grounds[3].setConnectedCorners(conCorner3);
	grounds[3].setConnectedSides(conSide3);
	grounds[3].setOn(true);
	// Create the walls; Start with top two vertices and then bottom two
	float wallVerts0[4][3] = {{200,0,50}, {400,10,50}, {400,0,50}, {200,0,50}};
	float wallVerts1[4][3] = {{200,0,-50}, {400,10,-50}, {400,0,-50}, {200,0,-50}};
	float wallVerts2[4][3] = {{400,10,50}, {400,10,-50}, {400,0,-50}, {400,0,50}};
	walls[0].setVertices(wallVerts0);
	walls[0].setOn(true);
	walls[1].setVertices(wallVerts1);
	walls[1].setOn(true);
	walls[2].setVertices(wallVerts2);
	walls[2].setOn(true);
	// Create the posts;
	float postPosition0[3] = {400,0,50};
	float postHeight0 = 10;
	float postPosition1[3] = {400,0,-50};
	float postHeight1 = 10;
	posts[0].setPosition(postPosition0);
	posts[0].setHeight(postHeight0);
	posts[0].setOn(true);
	posts[1].setPosition(postPosition1);
	posts[1].setHeight(postHeight1);
	posts[1].setOn(true);
}

// set up GL stuff
void setupGL() {
	// set the clear color
	glClearColor(0.5, 0.5, 0.5, 1.0);  // background color	
}


// This function is continuously called when events are not being received
// by the window.  This is a good place to update the state of your objects 
// after every frame.
void Idle() {
	glutPostRedisplay();

}

// keyboard handler
void Keyboard (unsigned char key, int , int ) {
	if (keyDown[key] == 0) keyDown[key]=1;
}

void KeyboardUp (unsigned char key, int , int ) {
	keyDown[key]=0;
}

void MouseButton(int button, int state, int x, int y) {
	if (button == GLUT_LEFT_BUTTON) {
		if (state == GLUT_DOWN && !mouseRight) mouseLeft = true;
		else if (state == GLUT_UP) mouseLeft = false;
	}
	else if (button == GLUT_RIGHT_BUTTON) {
		if (state == GLUT_DOWN && !mouseLeft) mouseRight = true;
		else if (state == GLUT_UP) mouseRight = false;
	}
	mousePosX = x;
	mousePosY = y;
}

void MouseMotion(int x, int y) {
	if (mouseLeft || mouseRight) {
		mouseVelX = x - mousePosX;
		mouseVelY = mousePosY - y; // the y-axis is flipped for mouse/screen positioning
	}
	mousePosX = x;
	mousePosY = y;
}

void MousePassiveMotion(int x, int y) {
	mousePosX = x;
	mousePosY = y;
}

// This functions handles what happens when the window is reshaped
void Reshape(int w, int h) {
	imageWidth = w;
	imageHeight = h;

    glViewport(0,0,w,h);
	double aspect = ((double)w) / ((double)h);
	glMatrixMode(GL_PROJECTION);
   	glLoadIdentity();
	gluPerspective(60,aspect,0.01, 10000);
}

// a cleanup function.  call this when you want to exit.
void quit(int i) {
	exit(i);
}

void drawString(float x, float y, void *font, string s, float r, float g, float b) {
	glColor3f(r, g, b);
	glRasterPos2f(x, y);
	for (int i=0; i<(signed)s.length(); i++)
		glutBitmapCharacter(font, s[i]);
}

string intToString(int i) {
	stringstream s;
	s << i;
	return s.str();
}

string floatToString(float f, int decNum) {
	stringstream s;
	string final;
	s << f;
	final = s.str();
	if (decNum != -1) {
		int position = final.find('.');
		if (position != string::npos) {
			 final = final.substr(0, position+1+decNum);
		}
	}
	return final;
}